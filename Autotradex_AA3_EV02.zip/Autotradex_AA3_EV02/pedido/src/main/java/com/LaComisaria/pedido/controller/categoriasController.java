
package com.LaComisaria.pedido.controller;

// Importaciones necesarias
import com.LaComisaria.pedido.model.categorias;
import com.LaComisaria.pedido.service.categoriasService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// Anotación @RestController indica que esta clase es un controlador REST de Spring
@RestController

// 
@RequestMapping("/categoria")
public class categoriasController {
    
    // La anotación @Autowired permite la inyección automática del servicio de categorías
    @Autowired
    private categoriasService categoriasService;
    
    // Método para manejar las solicitudes POST en "/Categoria/nuevo"
    @PostMapping("/nuevo")
    public categorias Newcategorias (@RequestBody categorias Newcategorias) {
        
        // Llama al método Newcategoria del servicio para crear una nueva categoría y la devuelve
        return this.categoriasService.Newcategorias(Newcategorias);
    }
    
    // Método para manejar las solicitudes GET en "/Categoria/mostrar"
    @GetMapping("/mostrar")
    public Iterable<categorias> getAll() {
        
        // Llama al método getAll del servicio para obtener todas las categorías y las devuelve
        return categoriasService.getAll();
    } 
    
    // Método para manejar las solicitudes POST en "/Categoria/modificar"
    @PostMapping("/modificar")
    public categorias updateCategorias(@RequestBody categorias categorias){
        
         // Llama al método modifycategoria del servicio para modificar una categoría y la devuelve
        return this.categoriasService.modifycategorias(categorias); 
    }
    
    // Método para manejar las solicitudes POST en "/Categoria/{id}" para eliminar una categoría
    @PostMapping(value = "/{id}")
    public Boolean deleteCategorias(@PathVariable(value="id") Integer id) {
        
        // Llama al método deletecategoria del servicio para eliminar una categoría y devuelve un valor booleano
        return this.categoriasService.deletecategorias(id);
    }
    
}
