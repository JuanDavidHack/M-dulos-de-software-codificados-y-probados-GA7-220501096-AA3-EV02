
package com.LaComisaria.pedido.controller;

import com.LaComisaria.pedido.model.empleado;
import com.LaComisaria.pedido.service.empleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/empleado")
public class empleadoController {
    
    @Autowired
    private empleadoService empleadoService;
    
    @PostMapping("/nuevo")
    public empleado Newempleado (@RequestBody empleado Newempleado) {
        return this.empleadoService.Newempleado(Newempleado);
    }
    
    @GetMapping("/mostrar")
    public Iterable<empleado> getAll() {
        return empleadoService.getAll();
    } 
    
    @PostMapping("/modificar")
    public empleado updateempleado(@RequestBody empleado empleado){
        return this.empleadoService.modifyempleado(empleado);
    }
    
    @PostMapping(value = "/{id}")
    public Boolean deleteempleado(@PathVariable(value="id") Integer id) {
        return this.empleadoService.deleteempleado(id);
    }
}

