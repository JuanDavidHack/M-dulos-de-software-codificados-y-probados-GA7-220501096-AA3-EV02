
package com.LaComisaria.pedido.model;

//Clase para relizar la entidad de la aplicación

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data

public class producto {
    @Id
    @Column
    private int id_producto;
    
    @Column
    private String nombre;
    
    @Column
    private int precio;
    
    @Column
    private String unit;
    
    @Column
    private int Categorias_idCategoria;
    
}
