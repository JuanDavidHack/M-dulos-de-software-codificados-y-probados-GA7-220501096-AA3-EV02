
package com.LaComisaria.pedido.controller;

import com.LaComisaria.pedido.model.horario;
import com.LaComisaria.pedido.service.horarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/horario")
public class horarioController {
    
    @Autowired
    private horarioService horarioService;
    
    @PostMapping("/nuevo")
    public horario NewHorarios (@RequestBody horario NewHorarios) {
        return this.horarioService.NewHorarios(NewHorarios);
    }
    
    @GetMapping("/mostrar")
    public Iterable<horario> getAll() {
     return horarioService.getAll();   
    }
    
    @PostMapping("/modificar")
    public horario UpdateHorario (@RequestBody horario horario) {
        return this.horarioService.modifyHorario(horario);
    }
    
    @PostMapping(value = "/{id}")
    public  Boolean deleteHorarios (@PathVariable (value = "id")Integer id) {
        return this.horarioService.deleteHorario(id);
    }
}
