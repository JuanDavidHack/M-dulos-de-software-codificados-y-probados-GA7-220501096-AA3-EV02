
package com.LaComisaria.pedido.controller;

import com.LaComisaria.pedido.model.asistencia;
import com.LaComisaria.pedido.service.asistenciaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

// Anotación @RestController indica que esta clase es un controlador REST de Spring
@RequestMapping("/asistencia")
public class asistenciaController {
    
    // La anotación @Autowired permite la inyección automática del servicio de categorías
    @Autowired
    private asistenciaService asistenciaService;
    
    // Método para manejar las solicitudes POST en "/Categoria/nuevo"
    @PostMapping("/nuevo")
    public asistencia Newasistencia (@RequestBody asistencia Newasistencia) {
        
        // Llama al método Newcategoria del servicio para crear una nueva categoría y la devuelve
        return this.asistenciaService.Newasistencia(Newasistencia);
    }
    
    // Método para manejar las solicitudes GET en "/Categoria/mostrar"
    @GetMapping("/mostrar")
    public Iterable<asistencia> getAll() {
        
        // Llama al método getAll del servicio para obtener todas las categorías y las devuelve
        return asistenciaService.getAll();
    } 
    
    // Método para manejar las solicitudes POST en "/Categoria/modificar"
    @PostMapping("/modificar")
    public asistencia updateAsistencia(@RequestBody asistencia asistencia){
        
         // Llama al método modifycategoria del servicio para modificar una categoría y la devuelve
        return this.asistenciaService.modifyasistencia(asistencia);
    }
    
    // Método para manejar las solicitudes POST en "/Categoria/{id}" para eliminar una categoría
    @PostMapping(value = "/{id}")
    public Boolean deleteasistencia(@PathVariable(value="id") Integer id) {
        
        // Llama al método deletecategoria del servicio para eliminar una categoría y devuelve un valor booleano
        return this.asistenciaService.deleteasistencia(id);
    }
    
}
