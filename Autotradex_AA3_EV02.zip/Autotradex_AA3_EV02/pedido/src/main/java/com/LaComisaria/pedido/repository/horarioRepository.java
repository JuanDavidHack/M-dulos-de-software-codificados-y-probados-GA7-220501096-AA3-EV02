
package com.LaComisaria.pedido.repository;

import com.LaComisaria.pedido.model.horario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface horarioRepository extends JpaRepository<horario, Integer> {
    
}
